

module RISCV_Pipelined_Processor(
    input clk,
    input reset,
    output [63:0] PC_In, PC_Out, ReadData1, ReadData2, WriteData, Result, Read_Data, imm_data,
    output [31:0] Instruction,
    output [6:0] opcode,
    output [4:0] rs1, rs2, rd,
    output [1:0] ALUOp,
    output [63:0] adder_out1, adder_out2,
    output Branch, MemRead, MemWrite, MemtoReg, ALUSrc, RegWrite, addermuxselect,
    output [63:0] index0, index1, index2, index3, index4, index5, index6,
    output [1:0] ForwardA, ForwardB,
    output Stall_Pipeline, Flush_Pipeline  
);

    // Declaration of all necessary wires
    wire [63:0] w_PC_In, w_PC_Out, Adder1Out, Adder2Out, Imm, w_WriteData, w_ReadData1, w_ReadData2, w_Result, w_Read_Data;
    wire [63:0] MuxmidOut;
    wire [31:0] w_Instruction;
    wire [6:0] Opcode, Funct7;
    wire [4:0] RD, RS1, RS2;
    wire [3:0] Funct, Operation;
    wire [2:0] Funct3;
    wire [1:0] w_ALUOp, ALUOp_Control;
    wire w_Branch, w_MemRead, w_MemWrite, w_MemtoReg, w_RegWrite, w_ALUSrc, Zero, sel_Branch;
    wire w_addermuxselect;
    wire [63:0] IFID_PC_Out;
    wire [31:0] IFID_Instruction;

    // Assign outputs
    assign PC_In = w_PC_In;
    assign PC_Out = w_PC_Out;
    assign Instruction = w_Instruction;
    assign ReadData1 = w_ReadData1;
    assign ReadData2 = w_ReadData2;
    assign WriteData = w_WriteData;
    assign Result = w_Result;
    assign Read_Data = w_Read_Data;
    assign opcode = Opcode;
    assign rs1 = RS1;
    assign rs2 = RS2;
    assign rd = RD;
    assign ALUOp = w_ALUOp;
    assign adder_out1 = Adder1Out;
    assign adder_out2 = Adder2Out;
    assign Branch = w_Branch;
    assign MemRead = w_MemRead;
    assign MemWrite = w_MemWrite;
    assign MemtoReg = w_MemtoReg;
    assign ALUSrc = w_ALUSrc;
    assign RegWrite = w_RegWrite;
    assign addermuxselect = w_addermuxselect;
    
    // Pipeline registers
    wire IDEX_Branch, IDEX_MemRead, IDEX_MemWrite, IDEX_MemtoReg, IDEX_RegWrite, IDEX_ALUSrc,
         EM_Branch, EM_MemRead, EM_MemWrite, EM_MemtoReg, EM_RegWrite, EM_Zero,
         MW_MemtoReg, MW_RegWrite;
    wire [1:0] IDEX_ALUOp;
    wire [3:0] IDEX_Funct;
    wire [4:0] IDEX_RS1, IDEX_RS2, IDEX_RD, EM_RD, MW_RD;
    wire [63:0] IDEX_PC_Out, IDEX_ReadData1, IDEX_ReadData2, IDEX_Imm,
                EM_Adder2Out, EM_Result, EM_WriteData, MW_Result, MW_Read_Data;

    // Forwarding wires
    wire [1:0] w_ForwardA, w_ForwardB;
    wire [63:0] ALU_InputA, ALU_InputB_pre;

    // Assign forwarding outputs
    assign ForwardA = w_ForwardA;
    assign ForwardB = w_ForwardB;

    // NEW: Pipeline control signals
    wire w_Stall_Pipeline, w_Flush_Pipeline;
    wire Branch_Predicted, Branch_Resolved;

    // Assign pipeline control outputs
    assign Stall_Pipeline = w_Stall_Pipeline;
    assign Flush_Pipeline = w_Flush_Pipeline;

    // NEW: Control signals after control mux
    wire Branch_mux, MemRead_mux, MemWrite_mux, MemtoReg_mux, RegWrite_mux, ALUSrc_mux;
    wire [1:0] ALUOp_mux;
    
    // Stage 1 - Instruction Fetch
    // NEW: PC stall logic - only update PC when not stalled
    wire PC_Write = !w_Stall_Pipeline;
    wire [63:0] PC_Next = sel_Branch ? EM_Adder2Out : Adder1Out;
    assign w_PC_In = PC_Next;  // Assign PC_In to PC_Next

    Program_Counter PC(
        .clk(clk & PC_Write),  // Only update PC when not stalled
        .reset(reset),
        .PC_In(w_PC_In),
        .PC_Out(w_PC_Out)
    );
    
    Adder add1(.A(w_PC_Out), .B(64'd4), .Out(Adder1Out));
    Instruction_Memory IM(.Inst_Address(w_PC_Out), .Instruction(w_Instruction));
    
    Branch_Prediction_Unit BPU(
        .clk(clk),
        .reset(reset),
        .PC(w_PC_Out),
        .Branch_Outcome(w_addermuxselect),
        .Branch_Resolved(EM_Branch),
        .Branch_Predicted(Branch_Predicted)
    );
    
    IF_ID ifid(
        .clk(clk),
        .reset(reset),
        .Stall(w_Stall_Pipeline),
        .Flush(w_Flush_Pipeline),
        .Instruction(w_Instruction),
        .PC_Out(w_PC_Out),
        .IFID_Instruction(IFID_Instruction),
        .IFID_PC_Out(IFID_PC_Out)
    );

    // Stage 2 - Instruction Decode
    // (Assume Instruction_Parser is defined elsewhere)
    Instruction_Parser IP(
        .Instruction(IFID_Instruction),
        .Opcode(Opcode),
        .RD(RD),
        .Funct3(Funct3),
        .RS1(RS1),
        .RS2(RS2),
        .Funct7(Funct7)
    );
    
    // (Assume Control_Unit is defined elsewhere)
    Control_Unit CU(
        .Opcode(Opcode),
        .ALUOp(ALUOp_Control),
        .Branch(w_Branch),
        .MemRead(w_MemRead),
        .MemtoReg(w_MemtoReg),
        .MemWrite(w_MemWrite),
        .ALUSrc(w_ALUSrc),
        .RegWrite(w_RegWrite)
    );
    
    Control_Mux ctrl_mux(
        .Stall(w_Stall_Pipeline),
        .Branch_in(w_Branch),
        .MemRead_in(w_MemRead),
        .MemWrite_in(w_MemWrite),
        .MemtoReg_in(w_MemtoReg),
        .RegWrite_in(w_RegWrite),
        .ALUSrc_in(w_ALUSrc),
        .ALUOp_in(ALUOp_Control),
        .Branch_out(Branch_mux),
        .MemRead_out(MemRead_mux),
        .MemWrite_out(MemWrite_mux),
        .MemtoReg_out(MemtoReg_mux),
        .RegWrite_out(RegWrite_mux),
        .ALUSrc_out(ALUSrc_mux),
        .ALUOp_out(ALUOp_mux)
    );
 
    Hazard_Detection_Unit HDU(
        .IF_ID_RS1(RS1),
        .IF_ID_RS2(RS2),
        .ID_EX_RD(IDEX_RD),
        .ID_EX_MemRead(IDEX_MemRead),
        .Branch(sel_Branch),
        .Jump(1'b0),  
        .Stall_Pipeline(w_Stall_Pipeline),
        .Flush_Pipeline(w_Flush_Pipeline)
    );
    
    // (Assume Imm_Gen is defined elsewhere)
    Imm_Gen IG(.Instruction(IFID_Instruction), .Imm(Imm));
    
    // (Assume RegisterFile is defined elsewhere)
    RegisterFile RF(
        .clk(clk),
        .reset(reset),
        .WriteData(w_WriteData),
        .RS1(RS1),
        .RS2(RS2),
        .RD(MW_RD),
        .RegWrite(MW_RegWrite),
        .ReadData1(w_ReadData1),
        .ReadData2(w_ReadData2)
    );
    
    assign Funct = {IFID_Instruction[30], IFID_Instruction[14:12]};
    
    ID_EX idex(
        .clk(clk),
        .reset(reset),
        .Stall(w_Stall_Pipeline),
        .Flush(w_Flush_Pipeline),
        .Branch(Branch_mux),
        .MemRead(MemRead_mux),
        .MemWrite(MemWrite_mux),
        .MemtoReg(MemtoReg_mux),
        .RegWrite(RegWrite_mux),
        .ALUSrc(ALUSrc_mux),
        .ALUOp(ALUOp_mux),
        .Funct(Funct),
        .RS1(RS1),
        .RS2(RS2),
        .RD(RD),
        .IFID_PC_Out(IFID_PC_Out),
        .ReadData1(w_ReadData1),
        .ReadData2(w_ReadData2),
        .Imm(Imm),
        .IDEX_Branch(IDEX_Branch),
        .IDEX_MemRead(IDEX_MemRead),
        .IDEX_MemWrite(IDEX_MemWrite),
        .IDEX_MemtoReg(IDEX_MemtoReg),
        .IDEX_RegWrite(IDEX_RegWrite),
        .IDEX_ALUSrc(IDEX_ALUSrc),
        .IDEX_ALUOp(IDEX_ALUOp),
        .IDEX_Funct(IDEX_Funct),
        .IDEX_RS1(IDEX_RS1),
        .IDEX_RS2(IDEX_RS2),
        .IDEX_RD(IDEX_RD),
        .IDEX_PC_Out(IDEX_PC_Out),
        .IDEX_ReadData1(IDEX_ReadData1),
        .IDEX_ReadData2(IDEX_ReadData2),
        .IDEX_Imm(IDEX_Imm)
    );

    Forwarding_Unit FU(
        .IDEX_RS1(IDEX_RS1),
        .IDEX_RS2(IDEX_RS2),
        .EXMEM_RD(EM_RD),
        .MEMWB_RD(MW_RD),
        .EXMEM_RegWrite(EM_RegWrite),
        .MEMWB_RegWrite(MW_RegWrite),
        .ForwardA(w_ForwardA),
        .ForwardB(w_ForwardB)
    );

    // (Assume Adder is defined elsewhere)
    Adder add2(.A(IDEX_PC_Out), .B(IDEX_Imm << 1), .Out(Adder2Out));

    // (Assume Mux_3x1 is defined elsewhere)
    Mux_3x1 forwardA_mux(
        .A(IDEX_ReadData1),
        .B(w_WriteData),       
        .C(EM_Result),       
        .S(w_ForwardA),
        .Out(ALU_InputA)
    );

    Mux_3x1 forwardB_mux(
        .A(IDEX_ReadData2),
        .B(w_WriteData),       
        .C(EM_Result),       
        .S(w_ForwardB),
        .Out(ALU_InputB_pre)
    );

    Branch_unit BU(
        .Funct3(IDEX_Funct[2:0]),
        .ReadData1(ALU_InputA),
        .ReadData2(ALU_InputB_pre),
        .addermuxselect(w_addermuxselect)
    );

    // (Assume Mux_2x1 is defined elsewhere)
    Mux_2x1 muxmid(.A(ALU_InputB_pre), .B(IDEX_Imm), .S(IDEX_ALUSrc), .Out(MuxmidOut));

    // (Assume ALU_Control and ALU64bit are defined elsewhere)
    ALU_Control AluC(.ALUOp(IDEX_ALUOp), .Funct(IDEX_Funct), .Operation(Operation));
    ALU64bit ALU(.A(ALU_InputA), .B(MuxmidOut), .ALUOp(Operation), .Result(w_Result), .Zero(Zero));

    // We check branch outcome in the execution stage
    assign Branch_Resolved = IDEX_Branch && w_addermuxselect;

    // (Assume EX_MEM is defined elsewhere)
    EX_MEM EM(
        .clk(clk),
        .reset(reset),
        .Branch(IDEX_Branch),
        .MemRead(IDEX_MemRead),
        .MemWrite(IDEX_MemWrite),
        .MemtoReg(IDEX_MemtoReg),
        .RegWrite(IDEX_RegWrite),
        .Zero(w_addermuxselect),
        .RD(IDEX_RD),
        .Adder2Out(Adder2Out),
        .Result(w_Result),
        .WriteData(ALU_InputB_pre),
        .EM_Branch(EM_Branch),
        .EM_MemRead(EM_MemRead),
        .EM_MemWrite(EM_MemWrite),
        .EM_MemtoReg(EM_MemtoReg),
        .EM_RegWrite(EM_RegWrite),
        .EM_Zero(EM_Zero),
        .EM_RD(EM_RD),
        .EM_Adder2Out(EM_Adder2Out),
        .EM_Result(EM_Result),
        .EM_WriteData(EM_WriteData)
    );
    
    assign sel_Branch = EM_Branch && EM_Zero;
    
    Data_Memory DM(
        .clk(clk),
        .MemWrite(EM_MemWrite),
        .MemRead(EM_MemRead),
        .Mem_Addr(EM_Result),
        .Write_Data(EM_WriteData),
        .Read_Data(w_Read_Data),
        .index0(index0),
        .index1(index1),
        .index2(index2),
        .index3(index3),
        .index4(index4),
        .index5(index5),
        .index6(index6)
    );
    
    MEM_WB MW(
        .clk(clk),
        .reset(reset),
        .MemtoReg(EM_MemtoReg),
        .RegWrite(EM_RegWrite),
        .RD(EM_RD),
        .EM_Result(EM_Result),
        .Read_Data(w_Read_Data),
        .MW_MemtoReg(MW_MemtoReg),
        .MW_RegWrite(MW_RegWrite),
        .MW_RD(MW_RD),
        .MW_Result(MW_Result),
        .MW_Read_Data(MW_Read_Data)
    );

    // Stage 5 - Write Back
    Mux_2x1 muxlast(.A(MW_Result), .B(MW_Read_Data), .S(MW_MemtoReg), .Out(w_WriteData));
    
    // For simulation purposes, assign imm_data
    assign imm_data = Imm;
endmodule