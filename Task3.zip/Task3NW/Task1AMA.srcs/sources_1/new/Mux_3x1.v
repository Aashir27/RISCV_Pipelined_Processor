

module Mux_3x1(
    input [63:0] A,   // Original value
    input [63:0] B,   // MEM/WB forwarded value
    input [63:0] C,   // EX/MEM forwarded value
    input [1:0] S,    // Select: 00-A, 01-B, 10-C
    output reg [63:0] Out
);

    always @(*) begin
        case(S)
            2'b00: Out = A;  // No forwarding
            2'b01: Out = B;  // Forward from MEM/WB
            2'b10: Out = C;  // Forward from EX/MEM
            default: Out = A;
        endcase
    end
endmodule
