module Branch_Prediction_Unit(
    input clk,
    input reset,
    input [63:0] PC,
    input Branch_Outcome,      
    input Branch_Resolved,     
    output reg Branch_Predicted // Prediction result
);
    
    reg [15:0] prediction_table;
    wire [3:0] index = PC[5:2]; // Use lower bits of PC as index
    
    // Initial values to prevent X states
    initial begin
        prediction_table = 16'b0; // Initialize to "not taken"
        Branch_Predicted = 1'b0;
    end
    
    // Make prediction based on history
    always @(*) begin
        Branch_Predicted = prediction_table[index];
    end
    
    
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            prediction_table <= 16'b0;
        end
        else if (Branch_Resolved) begin
            prediction_table[index] <= Branch_Outcome;
        end
    end
endmodule