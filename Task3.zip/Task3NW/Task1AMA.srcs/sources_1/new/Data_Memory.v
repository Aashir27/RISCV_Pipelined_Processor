
//module Data_Memory(
//    input clk,
//    input MemWrite,
//    input MemRead,
//    input [63:0] Mem_Addr,
//    input [63:0] Write_Data,
//    output reg [63:0] Read_Data,
//    output [63:0] index0,
//    output [63:0] index1,
//    output [63:0] index2,
//    output [63:0] index3,
//    output [63:0] index4,
//    output [63:0] index5,
//    output [63:0] index6
//);

//    reg [7:0] DataMemory [511:0];  // Increased memory size to accommodate 0x100 base address
//    integer i;
    
//    initial begin
//        // Initialize all memory locations to 0
//        for (i=0; i<512; i=i+1) begin
//            DataMemory[i] = 0;
//        end
        
//        // Initialize 4-byte values starting at 0x100 

//        DataMemory[256] = 8'd7;  // First value at 0x100
//        DataMemory[260] = 8'd6;  // Second value at 0x104
//        DataMemory[264] = 8'd5;  // Third value at 0x108
//        DataMemory[268] = 8'd4;  // Fourth value at 0x10C
//        DataMemory[272] = 8'd3;  // Fifth value at 0x110
//        DataMemory[276] = 8'd2;  // Sixth value at 0x114
//        DataMemory[280] = 8'd1;  // Seventh value at 0x118
//    end
    
//    // Update the indexN outputs to point to 4-byte values at their new locations
//    assign index0 = {{56{DataMemory[256][7]}}, DataMemory[256]};  // Sign extend
//    assign index1 = {{56{DataMemory[260][7]}}, DataMemory[260]};
//    assign index2 = {{56{DataMemory[264][7]}}, DataMemory[264]};
//    assign index3 = {{56{DataMemory[268][7]}}, DataMemory[268]};
//    assign index4 = {{56{DataMemory[272][7]}}, DataMemory[272]};
//    assign index5 = {{56{DataMemory[276][7]}}, DataMemory[276]};
//    assign index6 = {{56{DataMemory[280][7]}}, DataMemory[280]};
    
//    // Memory read logic - needs to handle 4-byte reads but convert to 8-byte format
//    always @ (*) begin
//        if (MemRead) begin
//            // Read 1 byte but sign-extend to 64 bits - this is the issue
//            Read_Data = {{56{DataMemory[Mem_Addr][7]}}, DataMemory[Mem_Addr]};
//        end
//        else begin
//            Read_Data = 64'b0;
//        end
//    end
    
//    // Memory write logic - needs to extract 4-byte value from 8-byte input
//    always @ (posedge clk) begin
//        if (MemWrite) begin
            
//            DataMemory[Mem_Addr] = Write_Data[7:0];
//        end
//    end
//endmodule

module Data_Memory(
    input clk,
    input MemWrite,
    input MemRead,
    input [63:0] Mem_Addr,
    input [63:0] Write_Data,
    output reg [63:0] Read_Data,
    output [63:0] index0,
    output [63:0] index1,
    output [63:0] index2,
    output [63:0] index3,
    output [63:0] index4,
    output [63:0] index5,
    output [63:0] index6
);

    reg [7:0] DataMemory [511:0];  // Increased memory size to accommodate 0x100 base address
    integer i;
    
    initial begin
        // Initialize all memory locations to 0
        for (i=0; i<512; i=i+1) begin
            DataMemory[i] = 0;
        end
        
        // Initialize 4-byte values starting at 0x100 
        // Each value is stored in 4 bytes instead of 8
        DataMemory[256] = 8'd7;  // First value at 0x100
        DataMemory[260] = 8'd6;  // Second value at 0x104
        DataMemory[264] = 8'd5;  // Third value at 0x108
        DataMemory[268] = 8'd4;  // Fourth value at 0x10C
        DataMemory[272] = 8'd3;  // Fifth value at 0x110
        DataMemory[276] = 8'd2;  // Sixth value at 0x114
        DataMemory[280] = 8'd1;  // Seventh value at 0x118
    end
    
    // Update the indexN outputs to point to 4-byte values at their new locations
    assign index0 = {{56{DataMemory[256][7]}}, DataMemory[256]};  // Sign extend
    assign index1 = {{56{DataMemory[260][7]}}, DataMemory[260]};
    assign index2 = {{56{DataMemory[264][7]}}, DataMemory[264]};
    assign index3 = {{56{DataMemory[268][7]}}, DataMemory[268]};
    assign index4 = {{56{DataMemory[272][7]}}, DataMemory[272]};
    assign index5 = {{56{DataMemory[276][7]}}, DataMemory[276]};
    assign index6 = {{56{DataMemory[280][7]}}, DataMemory[280]};
    
    // Memory read logic - needs to handle 4-byte reads but convert to 8-byte format
   always @ (*) begin
        if (MemRead) begin
            Read_Data = {{56{DataMemory[Mem_Addr][7]}}, DataMemory[Mem_Addr]};
        end
        else begin
            Read_Data = 64'b0;  // Default value when not reading
        end
    end

    // Memory write logic - needs to extract 4-byte value from 8-byte input
    always @ (posedge clk) begin
        if (MemWrite) begin
            // Store only lowest 4 bytes of the 8-byte input
            DataMemory[Mem_Addr] = Write_Data[7:0];
            DataMemory[Mem_Addr+1] = Write_Data[15:8];
            DataMemory[Mem_Addr+2] = Write_Data[23:16];
            DataMemory[Mem_Addr+3] = Write_Data[31:24];
        end
    end
endmodule