module Hazard_Detection_Unit(
    input [4:0] IF_ID_RS1,
    input [4:0] IF_ID_RS2,
    input [4:0] ID_EX_RD,
    input ID_EX_MemRead,
    input Branch,
    input Jump,
    output reg Stall_Pipeline,
    output reg Flush_Pipeline
);

    // Initial values
    initial begin
        Stall_Pipeline = 1'b0;
        Flush_Pipeline = 1'b0;
    end

    always @(*) begin
        // Default values
        Stall_Pipeline = 1'b0;
        Flush_Pipeline = 1'b0;
        
        // Load-use hazard detection
        if (ID_EX_MemRead && 
            ((ID_EX_RD == IF_ID_RS1) || (ID_EX_RD == IF_ID_RS2)) &&
            (ID_EX_RD != 5'b00000)) begin
            // Need to stall the pipeline
            Stall_Pipeline = 1'b1;
        end
        
        
        if (Branch || Jump) begin
            Flush_Pipeline = 1'b1;
        end
    end
endmodule