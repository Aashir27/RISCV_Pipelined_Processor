module Control_Mux(
    input Stall,
    input Branch_in, MemRead_in, MemWrite_in, MemtoReg_in, RegWrite_in, ALUSrc_in,
    input [1:0] ALUOp_in,
    output reg Branch_out, MemRead_out, MemWrite_out, MemtoReg_out, RegWrite_out, ALUSrc_out,
    output reg [1:0] ALUOp_out
);
    always @(*) begin
        if (Stall) begin
            // Insert bubble (NOP) by zeroing all control signals
            Branch_out = 1'b0;
            MemRead_out = 1'b0;
            MemWrite_out = 1'b0;
            MemtoReg_out = 1'b0;
            RegWrite_out = 1'b0;
            ALUSrc_out = 1'b0;
            ALUOp_out = 2'b00;
        end else begin
            // Pass through control signals
            Branch_out = Branch_in;
            MemRead_out = MemRead_in;
            MemWrite_out = MemWrite_in;
            MemtoReg_out = MemtoReg_in;
            RegWrite_out = RegWrite_in;
            ALUSrc_out = ALUSrc_in;
            ALUOp_out = ALUOp_in;
        end
    end
endmodule