

module IF_ID(
    input clk,
    input reset,
    input Stall,           // Stall signal from hazard detection
    input Flush,           // Flush signal
    input [31:0] Instruction,
    input [63:0] PC_Out,
    output reg [31:0] IFID_Instruction,
    output reg [63:0] IFID_PC_Out
);
    always @(posedge clk or posedge reset) begin
        if (reset == 1'b1) begin
            IFID_Instruction <= 0;
            IFID_PC_Out <= 0;
        end
        else if (Flush) begin
            // Flush the IF/ID pipeline register
            IFID_Instruction <= 32'h00000013; // NOP instruction (addi x0, x0, 0)
            IFID_PC_Out <= PC_Out;            //debugging
        end
        else if (!Stall) begin
            // Normal operation when not stalled
            IFID_Instruction <= Instruction;
            IFID_PC_Out <= PC_Out;
        end
        // When stalled, maintain current values (do nothing)
    end
endmodule