

`timescale 1ns / 1ps

module testbench_RISCV();
    reg clk, reset;
    wire [63:0] PC_In, PC_Out, ReadData1, ReadData2, WriteData, Result, Read_Data, imm_data;
    wire [31:0] Instruction;
    wire [6:0] opcode;
    wire [4:0] rs1, rs2, rd;
    wire [1:0] ALUOp;
    wire [63:0] adder_out1, adder_out2;
    wire Branch, MemRead, MemWrite, MemtoReg, ALUSrc, RegWrite, addermuxselect;
    wire [63:0] index0, index1, index2, index3, index4, index5, index6;
    wire [1:0] ForwardA, ForwardB;
    wire Stall_Pipeline, Flush_Pipeline;
    
    // Instantiate the processor
    RISCV_Pipelined_Processor DUT(
        .clk(clk),
        .reset(reset),
        .PC_In(PC_In),
        .PC_Out(PC_Out),
        .ReadData1(ReadData1),
        .ReadData2(ReadData2),
        .WriteData(WriteData),
        .Result(Result),
        .Read_Data(Read_Data),
        .imm_data(imm_data),
        .Instruction(Instruction),
        .opcode(opcode),
        .rs1(rs1),
        .rs2(rs2),
        .rd(rd),
        .ALUOp(ALUOp),
        .adder_out1(adder_out1),
        .adder_out2(adder_out2),
        .Branch(Branch),
        .MemRead(MemRead),
        .MemWrite(MemWrite),
        .MemtoReg(MemtoReg),
        .ALUSrc(ALUSrc),
        .RegWrite(RegWrite),
        .addermuxselect(addermuxselect),
        .index0(index0),
        .index1(index1),
        .index2(index2),
        .index3(index3),
        .index4(index4),
        .index5(index5),
        .index6(index6),
        .ForwardA(ForwardA),
        .ForwardB(ForwardB),
        .Stall_Pipeline(Stall_Pipeline),
        .Flush_Pipeline(Flush_Pipeline)
    );
    
    // Clock generation
    initial begin
        clk = 0;
        #5 clk = ~clk; // 10ns clock period
    end
    
   
    initial begin
        // Initialize and reset
        reset = 1;
        #20;
        reset = 0;
        
           end
endmodule