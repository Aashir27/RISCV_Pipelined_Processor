`timescale 1ns / 1ps

module Forwarding_Unit(
    input [4:0] IDEX_RS1, 
    input [4:0] IDEX_RS2,
    input [4:0] EXMEM_RD,
    input [4:0] MEMWB_RD,
    input EXMEM_RegWrite,
    input MEMWB_RegWrite,
    output reg [1:0] ForwardA,
    output reg [1:0] ForwardB
);

    always @(*) begin
        // Default: No forwarding
        ForwardA = 2'b00;
        ForwardB = 2'b00;
        
        // EX hazard for RS1 (EX/MEM forwarding)
        if (EXMEM_RegWrite && (EXMEM_RD != 0) && (EXMEM_RD == IDEX_RS1)) begin
            ForwardA = 2'b10;
        end
        
        // EX hazard for RS2 (EX/MEM forwarding)
        if (EXMEM_RegWrite && (EXMEM_RD != 0) && (EXMEM_RD == IDEX_RS2)) begin
            ForwardB = 2'b10;
        end
        
        // MEM hazard for RS1 (MEM/WB forwarding)
        if (MEMWB_RegWrite && (MEMWB_RD != 0) && 
            !(EXMEM_RegWrite && (EXMEM_RD != 0) && (EXMEM_RD == IDEX_RS1)) && 
            (MEMWB_RD == IDEX_RS1)) begin
            ForwardA = 2'b01;
        end
        
        // MEM hazard for RS2 (MEM/WB forwarding)
        if (MEMWB_RegWrite && (MEMWB_RD != 0) && 
            !(EXMEM_RegWrite && (EXMEM_RD != 0) && (EXMEM_RD == IDEX_RS2)) && 
            (MEMWB_RD == IDEX_RS2)) begin
            ForwardB = 2'b01;
        end
    end
endmodule